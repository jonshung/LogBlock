Use-Case Specification Changes:
- All previous Use Case Specifications are discarded for re-specification.
- All previous Use Case Diagrams are discarded, in-replace for two major diagrams.
- Specifications of Use Case 01 to Use Case 24 are conducted by Ngũ Kiệt Hùng.
- All new diagrams are conducted by Ngũ Kiệt Hùng
